<?php
namespace GuzzleHttp\Exception;

class StateException extends TransferException {};
