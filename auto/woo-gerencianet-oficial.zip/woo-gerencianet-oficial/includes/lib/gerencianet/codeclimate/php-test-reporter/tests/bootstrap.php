<?php

$loader = require realpath(__DIR__ . '/../vendor/autoload.php');
$loader->add('CodeClimate', __DIR__);
